# This file was automatically created by FeynRules 2.3.32
# Mathematica version: 11.1.1 for Linux x86 (64-bit) (April 18, 2017)
# Date: Tue 25 Jun 2019 23:07:36


from object_library import all_orders, CouplingOrder


DMS = CouplingOrder(name = 'DMS',
                    expansion_order = 2,
                    hierarchy = 2)

QCD = CouplingOrder(name = 'QCD',
                    expansion_order = 99,
                    hierarchy = 1)

QED = CouplingOrder(name = 'QED',
                    expansion_order = 99,
                    hierarchy = 2)

